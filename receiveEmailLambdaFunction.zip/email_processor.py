# email_processor.py

from bs4 import BeautifulSoup
import html2text


def strip_html_css(email_content):

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(email_content, 'html.parser')

    # Remove <style> tags (CSS)
    for style in soup.find_all('style'):
        style.decompose()

    # Remove all HTML tags
    text = soup.get_text(separator='\n', strip=True)

    return text


def reduce_email_size(email_content):

    indexOfDoctype = email_content.find("<!DOCTYPE")
    
    if indexOfDoctype != -1:
        email_content = email_content[indexOfDoctype:]

    plain_text = html2text.html2text(strip_html_css(email_content))
    return plain_text


def get_cashtag(clean_text):
    
    indexOfPaymentFrom = clean_text.find("Payment to $")
    clean_text = clean_text[indexOfPaymentFrom + 12:]
    indexOfEndOfTag = clean_text.find(' ')
    
    cashtag = clean_text[:indexOfEndOfTag]
    return cashtag


def get_amount(clean_text):
    print(clean_text)
    
    indexOfPaymentFrom = clean_text.find("Amount $")
    clean_text = clean_text[indexOfPaymentFrom + 8:]
    indexOfEndOfTag = clean_text.find(' ')
    
    amount = clean_text[:indexOfEndOfTag]
    return amount