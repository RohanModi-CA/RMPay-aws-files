import boto3
import email_processor
from datetime import datetime, timezone

# Initialize S3 client
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cap-jdsa233293ijnDSdjn23IlHnNSbA3nSD')

def lambda_handler(event, context):
    # Bucket name and object key
    bucket_name = 'cap-inbox-27iyst3zdkrhhcbfzwjz4onbx277p42o46nramwqotyhcsw4g8ofp'
    file_key = event['Records'][0]['s3']['object']['key']

    try:
        # Fetch the file from S3
        response = s3.get_object(Bucket=bucket_name, Key=file_key)

        # Read content of the file
        file_content = response['Body'].read().decode('utf-8')
        
        # Process the file content
        file_content = email_processor.reduce_email_size(file_content)
        file_content = email_processor.strip_html_css(file_content)
        
        cashtag = email_processor.get_cashtag(file_content)
        amount = email_processor.get_amount(file_content)
        
        store_in_dynamodb(cashtag, amount, datetime.now(timezone.utc))
        
        # Optionally, you can return the content or process it further
        return {
            'statusCode': 200,
            'body': file_content
        }
    except Exception as e:
        print(f"Error reading file from S3: {str(e)}")
        raise e

def store_in_dynamodb(cashtag, amount, utc_time):
    table.put_item(
        Item={
            'cap-reference': f"{utc_time.isoformat()}-{cashtag}-{amount}",
            'cashtag': cashtag,
            'amount': int(float(amount)*100.0),
            'utc_time': utc_time.isoformat()
        }
    )
